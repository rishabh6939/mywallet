package com.myapplication.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prepare4jobApplication {

    public static void main(String[] args) {
        SpringApplication.run(Prepare4jobApplication.class, args);
    }

}
